public abstract class Shape
{
	public abstract double getArea();
	public abstract double getCircumference();   
	public abstract void move(double disp_x, double disp_y);
	public String toString()
	{
		return "Shape[]";
	}
}
