/**
 * Manage books using random access files
 * @author Yukun
 */
import java.io.*;

public class Books 
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // parse command line input
        // for simplicity, NumberFormatException is not checked
        if (args.length < 2)
        {
            System.out.println("Wrong command line input");
            System.exit(1);
        }
        
        try
        {
            RandomAccessFile file = new RandomAccessFile("books", "rw");

            if (args[0].equalsIgnoreCase("add")) // add a record
            {
                // add <book_id> <title> <authors> <year>
                if (args.length != 5)
                {
                    System.out.println("Wrong command line input");
                    System.exit(3);
                }
                // command line input
                BookRecord newRecord = new BookRecord();
                newRecord.setNumber(Integer.parseInt(args[1]));
                newRecord.setTitle(args[2]);
                newRecord.setAuthors(args[3]);
                newRecord.setYear(Integer.parseInt(args[4]));
                
                // check if the record exists
                int max_id = (int)(file.length() / BookRecord.size());
                if (newRecord.getNumber() <= max_id)
                {
                    BookRecord oldRecord = new BookRecord();
                    file.seek((newRecord.getNumber() - 1) * BookRecord.size());
                    oldRecord.read(file);
                    if (oldRecord.getNumber() > 0) // record already exists
                    {
                        System.out.println("Record number " + newRecord.getNumber() + " already exists!");
                        System.exit(5);
                    }
                }
                
                // new record
                file.seek((newRecord.getNumber() - 1) * BookRecord.size());
                newRecord.write(file);
                System.out.println("Record number " + newRecord.getNumber() + " successfully added.");
            }
            else if (args[0].equalsIgnoreCase("query")) // query
            {
                int book_id = Integer.parseInt(args[1]);
                int max_id = (int)(file.length() / BookRecord.size());
                
                if (book_id <= max_id) // attempt to retrieve the record
                {
                    BookRecord oldRecord = new BookRecord();
                    file.seek((book_id - 1) * BookRecord.size());
                    oldRecord.read(file);
                    if (oldRecord.getNumber() > 0) // record exists
                    {
                        System.out.println("Book ID: " + oldRecord.getNumber());
                        System.out.println("Title: " + oldRecord.getTitle().trim());    // trim is used to remove unnecessary spaces
                        System.out.println("Authors: " + oldRecord.getAuthors().trim());
                        System.out.println("Year: " + oldRecord.getYear());
                    }
                    else
                    {
                        System.out.println("Record does not exist");
                    }
                }
                else
                {
                    System.out.println("Record does not exist");
                }                
            }
            else if (args[0].equalsIgnoreCase("delete")) // delete a record
            {
                int book_id = Integer.parseInt(args[1]);
                int max_id = (int)(file.length() / BookRecord.size());
                
                if (book_id <= max_id) // attempt to retrieve the record
                {
                    BookRecord oldRecord = new BookRecord();
                    file.seek((book_id - 1) * BookRecord.size());
                    oldRecord.read(file);
                    if (oldRecord.getNumber() > 0) // record exists
                    {
                        oldRecord.setNumber(0);     // as long as the book_id is set to zero, the record is considered as deleted
                        file.seek((book_id - 1) * BookRecord.size());
                        oldRecord.write(file);
                        System.out.println("Record number " + book_id + " deleted.");
                    }
                    else
                    {
                        System.out.println("Record does not exist");
                    }
                }
                else
                {
                    System.out.println("Record does not exist");
                }                
            }
            else // wrong command
            {
                System.out.println("Unknown command, only add/query/delete are supported.");
                System.exit(2);
            }
            
            file.close();
        }
        catch (IOException ioe)
        {
            System.out.println(ioe);
            System.exit(4);
        }
    }
}
