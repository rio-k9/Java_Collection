/**
 * Book Record
 * @author Yukun
 */
import java.io.*;

public class BookRecord 
{
    // method to read a record from a random access file
    public void read(RandomAccessFile file) throws IOException
    {
        number = file.readInt();
        char chTitle[] = new char[100];
        for (int i = 0; i < chTitle.length; i++)
        {
            chTitle[i] = file.readChar();
        }
        title = new String(chTitle);
        char chAuthors[] = new char[50];
        for (int i = 0; i < chAuthors.length; i++)
        {
            chAuthors[i] = file.readChar();
        }
        authors = new String(chAuthors);
        year = file.readInt();
    }
    
    // method to write a record to a random access fule
    public void write(RandomAccessFile file) throws IOException
    {
        file.writeInt(number);
        // write up to first 100 characters
        if (title.length() <= 100)
        {
            file.writeChars(title);
            for (int i = title.length(); i < 100; i++)  // output the padding spaces
            {
                file.writeChar(' ');
            }
        }
        else 
        {
            file.writeChars(title.substring(0, 100));
        }   
        
        // write up to first 50 characters
        if (authors.length() <= 50)
        {
            file.writeChars(authors);
            for (int i = authors.length(); i < 50; i++) // output the padding spaces
            {
                file.writeChar(' ');
            }
        }
        else
        {
            file.writeChars(authors.substring(0, 50));
        }     
        file.writeInt(year);
    }
    
    // methods to get and set variables
    public void setNumber(int n) { number = n; }
    public void setTitle(String t) { title = t; }
    public void setAuthors(String a) { authors = a; }
    public void setYear(int y) { year = y; }
    
    public int getNumber() { return number; }
    public String getTitle() { return title; }
    public String getAuthors() { return authors; }
    public int getYear() { return year; }
    
    // return the size of the record
    public static int size() { return 308; }
    
    // instance variables
    private int number;
    private String title;
    private String authors;
    private int year;
}
