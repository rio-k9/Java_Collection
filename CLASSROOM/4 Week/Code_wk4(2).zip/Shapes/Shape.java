public class Shape {
   float getArea( ) {
      return 0.0f;
   }
}