/**
 * Lab 2, Question 2.1
 * Enter the number by keyboard and print whether this number is/is not 
 * a prime number
 * @author Yukun
 */

import java.io.*;

public class Prime1 
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        BufferedReader reader = new BufferedReader( 
                new InputStreamReader(System.in));
        
        System.out.print("Enter number >> ");
        int num = 0;
        try
        {
            String s = reader.readLine();
            num = Integer.parseInt(s);
        }
        catch (IOException ioe)  // if IO exception
        {
            System.out.println(ioe);
            System.exit(1);
        }
        catch (NumberFormatException nfe)
        {
            System.out.println("Input is not a proper number!");
            System.exit(2);
        }
        
        // now check if num is a prime number
        // we attempt to divide num by 2, 3, ... (num-1)
        // but it is sufficient to try until sqrt(num)
        boolean isPrime = true;
        if (num < 2)
        {
            isPrime = false;
        }
        else
        {    
            for (int i = 2; i < num; i++)
            {
                if (num % i == 0)
                {
                    isPrime = false;
                    break;
                }
            }
        }
        
        // output message based on whether num is or is not a prime number
        if (isPrime)
        {
            System.out.println(num + " is a prime number");
        }
        else
        {
            System.out.println(num + " is not a prime number");
        }
    }
}
