/**
 * Lab 2, Question 2.3
 * Obtain the number from the command line and print whether this number is/is not 
 * a prime number
 * @author Yukun
 */

public class Prime3
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        if (args.length != 1)
        {
            System.out.println("One command line argument is expected!");
            System.exit(1);
        }
        
        int num = 0;
        try
        {
            num = Integer.parseInt(args[0]);    // parse integer from the first command line argument
        }
        catch (NumberFormatException nfe)
        {
            System.out.println("Wrong command line argument!");
            System.exit(2);
        }
        
        // now check if num is a prime number
        // we attempt to divide num by 2, 3, ... (num-1)
        // but it is sufficient to try until sqrt(num)
        boolean isPrime = true;
        if (num < 2)
        {
            isPrime = false;
        }
        else
        {    
            for (int i = 2; i < num; i++)
            {
                if (num % i == 0)
                {
                    isPrime = false;
                    break;
                }
            }
        }
        
        // output message based on whether num is or is not a prime number
        if (isPrime)
        {
            System.out.println(num + " is a prime number");
        }
        else
        {
            System.out.println(num + " is not a prime number");
        }
    }
}
