/**
 * Lab 2, Question 2.2
 * Enter the number by keyboard and print whether this number is/is not 
 * a prime number
 * Keeps asking for the number until QUIT is entered
 * @author Yukun
 */

import java.io.*;

public class Prime2
{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        BufferedReader reader = new BufferedReader( 
                new InputStreamReader(System.in));
                
        while (true)    // make trying
        {
            System.out.print("Enter number >> ");
            int num = 0;
            try
            {
                String s = reader.readLine();
                if (s.compareToIgnoreCase("QUIT") == 0) // if quit is entered, exit from the loop (case insensitive comparison is used here)
                    break;
                
                num = Integer.parseInt(s);
            }
            catch (IOException ioe)  // if IO exception
            {
                System.out.println(ioe);
                System.exit(1);
            }
            catch (NumberFormatException nfe)       // if input is not a proper number, make another attempt
            {
                System.out.println("Input is not a proper number!");
                continue;
            }
        
            // now check if num is a prime number
            // we attempt to divide num by 2, 3, ... (num-1)
            // but it is sufficient to try until sqrt(num)
            boolean isPrime = true;
            if (num < 2)
            {
                isPrime = false;
            }
            else
            {    
                for (int i = 2; i < num; i++)
                {
                    if (num % i == 0)
                    {
                        isPrime = false;
                        break;
                    }
                }
            }
            
            // output message based on whether num is or is not a prime number
            if (isPrime)
            {
                System.out.println(num + " is a prime number");
            }
            else
            {
                System.out.println(num + " is not a prime number");
            }
        }
    }
}
