// Use of methods toRadians and sin of the Math class
import java.lang.Math;
public class SineMore
{
   public static void main( String[] args )
   {
      int degrees = 30;
      double radians = Math.toRadians( degrees );
      System.out.println( Math.sin( radians ) );
   }
}
