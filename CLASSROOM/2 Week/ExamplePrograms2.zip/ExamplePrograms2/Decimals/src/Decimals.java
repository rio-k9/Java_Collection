import java.text.NumberFormat;
public class Decimals
{
   //
   // Division of numbers 1 to 8 by 8
   //
   public static void main(String[] args)
   {
      //
      // Display numbers with two decimal places
      //
      NumberFormat formatter = 
               NumberFormat.getNumberInstance();
      formatter.setMinimumFractionDigits( 2 );
      formatter.setMaximumFractionDigits( 2 );
      double number, result;
      for ( number = 1; number <= 8; number++ )
      {
         result = number / 8;
         System.out.println( 
                   formatter.format( result ) );
      }
   }
}

