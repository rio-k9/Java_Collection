public class Even
{
   public static void main(String[] args)
   {
      int number = 23;
      if ( ( number % 2 ) == 0 ) 
         System.out.println( number
                        + " is an even number" );
      else 
         System.out.println( number 
                        + " is an odd number" );
   }
}
