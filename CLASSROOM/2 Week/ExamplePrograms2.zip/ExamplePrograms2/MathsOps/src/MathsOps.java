//
// Mathematical Operators
//
public class MathsOps
{
   public static void main(String[] args)
   {
      int a, b, c, d, e; 		
      a = 128;			
      b = 6;			
      c = a * b;
      d = a / b;
      e = a % b;
      System.out.println("a = " + a + "  b = " + b
          + "  c = " + c + "  d = " + d + "  e = " + e);
   }
}
