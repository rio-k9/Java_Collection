// Program using the PrintStream class to produce
// formatted output
//
import java.io.PrintStream;
public class FormatOutput
{
   public static void main(String[] args)
   {
      PrintStream output = 
                  new PrintStream( System.out );
      String str = "Output";
      int inum=27;
      double dnum = 13.75;
      // output right justified values
      output.format("%7s%7d%7.2f\n", 
                              str, inum, dnum );
      // output left justified values
      output.format("%-7s%-7d%-7.2f\n",
                              str, inum, dnum );
      // output values with no leading spaces
      output.format("String is %s", str );
      // calling the printf method is the same as
      // calling the format method
      output.printf("  Integer is %d", inum );
      output.printf("  Real Number is %.2f\n",
                     dnum );
      // check no error has occurred while using  
      // PrintStream methods
      output.println( output.checkError() );
   }
}
