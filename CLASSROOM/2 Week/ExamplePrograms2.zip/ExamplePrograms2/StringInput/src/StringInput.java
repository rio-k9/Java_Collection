import java.util.Scanner;
public class StringInput
{
   public static void main( String[] args )
   {
      // set up keyboard input
      Scanner in = new Scanner( System.in );
      // read lines until EOF
      while ( in.hasNextLine() )
      {
         String line = in.nextLine();
         if (line.equals("")) break;
         System.out.println( line );
         // split line into tokens
         Scanner elements = new Scanner( line );
         // display each token in line
         while ( elements.hasNext() )
         {
            String str = elements.next();
            System.out.println( str );  
         }
         elements.close();
      }
      in.close();
   }
}
