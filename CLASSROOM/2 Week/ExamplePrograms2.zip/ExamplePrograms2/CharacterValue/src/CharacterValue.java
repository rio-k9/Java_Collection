public class CharacterValue
{
   public static void main( String[] args )
   {
      char ch = 'A';
      System.out.println( ch );
      System.out.println( (int) ch );
   }
}
