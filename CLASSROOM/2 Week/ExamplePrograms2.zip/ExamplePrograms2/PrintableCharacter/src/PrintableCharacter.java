public class PrintableCharacter
{
   public static void main( String[] args )
   {
      int number = 65;
      System.out.println( number );
      System.out.println( (char) number );
   }
}
