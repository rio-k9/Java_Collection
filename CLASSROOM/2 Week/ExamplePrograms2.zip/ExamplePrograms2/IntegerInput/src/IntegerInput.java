import java.util.Scanner;
public class IntegerInput
{
   public static void main( String[] args )
   {
      Scanner in = new Scanner( System.in );
      while ( in.hasNextLine() )
      {
         String line = in.nextLine();
         if (line.equals("")) break;
         System.out.println( line );
         Scanner elements = new Scanner( line );
         while ( elements.hasNextInt() )
         {
            int number = elements.nextInt();
            System.out.println( number );  
         }
         elements.close();
      }
      in.close();
   }
}









