//
// Printing of a tab and a backslash
//
public class Escapes
{
   public static void main( String[] args )
   {
      System.out.print( "Hello\t" );
      System.out.print( "World\n" ); 
      System.out.println( "The path is C:\\WINNT" );
      System.out.println( "\u03c0 is close to 3.142" );
   }
}
