public class PhoneBookEntryTest {
	public static void main( String[] args) {
		PhoneBookEntry e = new PhoneBookEntry("bob", "+44 0123456789");
		System.out.println(e);
	}
}