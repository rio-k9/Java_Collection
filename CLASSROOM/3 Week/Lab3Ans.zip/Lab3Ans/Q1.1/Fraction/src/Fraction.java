/**
 * Fraction class
 * @author Yukun
 */
public class Fraction
{
    /**
     * Constructor
     * @param nominatorValue
     * @param denominatorValue 
     */
    public Fraction( int nominatorValue, int denominatorValue )
    {
        nominator = nominatorValue;
        denominator = denominatorValue;
    }
    
    /**
     * Add two fraction numbers
     * @param another
     * @return result
     */
    public Fraction add (Fraction another)
    {
        Fraction result = new Fraction(nominator * another.denominator + denominator * another.nominator, this.denominator * another.denominator);
        return result; 
    }
    
    /**
     * Subtract two fraction numbers
     * @param another
     * @return result
     */
    
    public Fraction subtract (Fraction another)
    {
        Fraction result = new Fraction(nominator * another.denominator - denominator * another.nominator, this.denominator * another.denominator);
        return result; 
    }
    
    /**
     * Multiply two fraction numbers
     * @param another
     * @return result
     */
    
    public Fraction multiple (Fraction another)
    {
        Fraction result = new Fraction(nominator * another.nominator, this.denominator * another.denominator);
        return result; 
    }
    
    /**
     * Divide two fraction numbers
     * @param another
     * @return result
     */
    public Fraction divide (Fraction another)
    {
        Fraction result = new Fraction(nominator * another.denominator, this.denominator * another.nominator);
        return result; 
    }
    
    /**
     * Output the current fraction number
     */
    public void output ( )
    {
        System.out.print(this.nominator + "/" + this.denominator);
    } 
    
    private int nominator;
    private int denominator;
}	
	
