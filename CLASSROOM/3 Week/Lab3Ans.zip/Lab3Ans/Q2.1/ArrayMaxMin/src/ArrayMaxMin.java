/**
 * Finding the max/min numbers of an array
 * @author Yukun
 */

public class ArrayMaxMin 
{
    /**
     * Get the min. value of the int array
     * @param arr input array
     * @return min. value
     */
    private static int getMin(int[] arr)
    {
        // check prerequisite for completeness
        // not required for the exercise
        if (arr == null)    // null input?
        {
            throw new IllegalArgumentException("array should not be null");
        }
        if (arr.length == 0)    // no element?
        {
            throw new IllegalArgumentException("no element in the array");
        }
        
        int minValue = arr[0];
        for (int i = 1; i < arr.length; i++)
        {
            if (arr[i] < minValue)
            {
                minValue = arr[i];
            }
        }
        
        return minValue;
    }

    /**
     * Get the max. value of the int array
     * @param arr input array
     * @return max. value
     */
    private static int getMax(int[] arr)
    {
        // check prerequisite for completeness
        // not required for the exercise
        if (arr == null)    // null input?
        {
            throw new IllegalArgumentException("array should not be null");
        }
        if (arr.length == 0)    // no element?
        {
            throw new IllegalArgumentException("no element in the array");
        }
        
        int maxValue = arr[0];
        for (int i = 1; i < arr.length; i++)
        {
            if (arr[i] > maxValue)
            {
                maxValue = arr[i];
            }
        }
        
        return maxValue;
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int[] values = {5, -1, 2, 3, 100, -123, 235, 5, 8, 0, 7};
        
        System.out.println("Min: " + getMin(values));
        System.out.println("Max: " + getMax(values));
    }
}
