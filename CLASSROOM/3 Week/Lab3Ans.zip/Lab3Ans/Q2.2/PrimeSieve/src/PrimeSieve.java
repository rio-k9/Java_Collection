/**
 * Finding all the prime numbers from 1 to n using 
 * Sieve of Eratosthenes
 * @author Yukun
 */
public class PrimeSieve {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        int n = 20; // max. number
    
        // whether the number has been crossed
        // those not crossed at the end are prime numbers
        // for value i, we store it at crossed[i], so crossed[0] is ignored
        // we need to allocate n+1 spaces (to allow crossed[n])
        // alternative approach to use crossed[0] is also fine
        boolean[] crossed = new boolean[n + 1]; 
        
        // initialise all the number to be not crossed
        for (int i = 0; i <= n; i++)
        {
            crossed[i] = false;
        }
        
        crossed[1] = true;  // cross out 1
        for (int i = 2; i <= n; i++)
        {
            if (!crossed[i])     // find the first not crossed element
            {
                for (int k = i * 2; k <= n; k += i) // cross out multiples 
                {
                    crossed[k] = true;
                }
            }
        }
        
        // print all the remaining (not crossed) elements
        for (int i = 1; i <= n; i++)
        {
            if (!crossed[i])
            {
                System.out.println(i);
            }
        }
    }
}
